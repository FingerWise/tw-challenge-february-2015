# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rake db:seed (or created alongside the db with db:setup).
#
# Examples:
#
#   cities = City.create([{ name: 'Chicago' }, { name: 'Copenhagen' }])
#   Mayor.create(name: 'Emanuel', city: cities.first)

u = User.create email: 'test@test.com', password: 'password'

cc = CreditCard.create card_type: 'MASTERCARD', number: '4242424242424242', exp_month: 2, exp_year: 2016, cvc: '314', default: true

u.credit_cards << cc
