class CreateCreditCards < ActiveRecord::Migration
  def change
    create_table :credit_cards do |t|
      t.string :card_type
      t.string :number
      t.integer :exp_month
      t.integer :exp_year
      t.string :cvc
      t.boolean :default
      t.integer :user_id

      t.timestamps null: false
    end
  end
end
