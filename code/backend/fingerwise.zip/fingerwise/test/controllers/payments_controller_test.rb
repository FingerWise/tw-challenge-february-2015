require 'test_helper'

class PaymentsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
