class FingerPayment

  API_KEY = "sk_test_hsoL0WoaSsfjAc46TKmDHj0S"

  def self.pay fingerprint_key1, fingerprint_key2, payment_details
    make_payment authorize(fingerprint_key1, fingerprint_key2), payment_details
  end

  def self.authorize fingerprint_key1, fingerprint_key2
    # returns user
    User.first
  end

  def self.make_payment user, payment_details
    Stripe.api_key = API_KEY

    Stripe::Charge.create(payment_details.merge({ source: user.default_credit_card.relevant_data }))
  end

end
