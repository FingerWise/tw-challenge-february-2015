require 'finger_payment'

class PaymentsController < ApplicationController

  DEFAULT_CURRENCY = 'eur'

  def create
    response = FingerPayment.pay(
      params[:fingerprint_key1],
      params[:fingerprint_key2],
      amount: params[:amount].to_i,
      currency: DEFAULT_CURRENCY,
      description: params[:description]
    )

    if response
      render json: {}, status: 200
    else
      render json: {}, status: 401
    end
  end

end
