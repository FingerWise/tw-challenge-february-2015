class CreditCard < ActiveRecord::Base
  belongs_to :user

  scope :default, -> { where(default: true) }

  def relevant_data
    {
      number:    number,
      exp_month: exp_month,
      exp_year:  exp_year,
      cvc:       cvc
    }
  end
end
